<template>
  <div style="padding:30px;">
    <el-alert :closable="false" title="二级菜单"/>
  </div>
</template>
