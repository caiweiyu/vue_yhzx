<template>
  <div style="padding:30px;">
    <el-alert :closable="false" title="三级菜单2" type="success">
      <router-view />
    </el-alert>
  </div>
</template>
